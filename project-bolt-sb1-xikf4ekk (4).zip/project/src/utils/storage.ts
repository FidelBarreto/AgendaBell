export interface Appointment {
  id: string;
  client: string;
  service: string;
  time: string;
  date: string;
  phone: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  price: number;
  createdAt: string;
}

export interface Service {
  id: string;
  name: string;
  duration: number;
  price: number;
}

const APPOINTMENTS_KEY = 'agendabell_appointments';
const SERVICES_KEY = 'agendabell_services';

// Appointments Storage
export const saveAppointment = (appointment: Omit<Appointment, 'id' | 'createdAt'>): Appointment => {
  const appointments = getAppointments();
  const newAppointment: Appointment = {
    ...appointment,
    id: generateId(),
    createdAt: new Date().toISOString(),
  };
  
  appointments.push(newAppointment);
  localStorage.setItem(APPOINTMENTS_KEY, JSON.stringify(appointments));
  return newAppointment;
};

export const getAppointments = (): Appointment[] => {
  const stored = localStorage.getItem(APPOINTMENTS_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const updateAppointment = (id: string, updates: Partial<Appointment>): void => {
  const appointments = getAppointments();
  const index = appointments.findIndex(apt => apt.id === id);
  
  if (index !== -1) {
    appointments[index] = { ...appointments[index], ...updates };
    localStorage.setItem(APPOINTMENTS_KEY, JSON.stringify(appointments));
  }
};

export const deleteAppointment = (id: string): void => {
  const appointments = getAppointments();
  const filtered = appointments.filter(apt => apt.id !== id);
  localStorage.setItem(APPOINTMENTS_KEY, JSON.stringify(filtered));
};

// Services Storage
export const getServices = (): Service[] => {
  const stored = localStorage.getItem(SERVICES_KEY);
  if (!stored) {
    // Initialize with default services
    const defaultServices: Service[] = [
      { id: '1', name: 'Corte Feminino', duration: 45, price: 60 },
      { id: '2', name: 'Corte + Escova', duration: 90, price: 80 },
      { id: '3', name: 'Manicure', duration: 45, price: 35 },
      { id: '4', name: 'Pedicure', duration: 45, price: 40 },
      { id: '5', name: 'Sobrancelha', duration: 30, price: 25 },
      { id: '6', name: 'Depilação Perna', duration: 60, price: 70 },
    ];
    localStorage.setItem(SERVICES_KEY, JSON.stringify(defaultServices));
    return defaultServices;
  }
  return JSON.parse(stored);
};

export const saveService = (service: Omit<Service, 'id'>): Service => {
  const services = getServices();
  const newService: Service = {
    ...service,
    id: generateId(),
  };
  
  services.push(newService);
  localStorage.setItem(SERVICES_KEY, JSON.stringify(services));
  return newService;
};

export const updateService = (id: string, updates: Partial<Service>): void => {
  const services = getServices();
  const index = services.findIndex(service => service.id === id);
  
  if (index !== -1) {
    services[index] = { ...services[index], ...updates };
    localStorage.setItem(SERVICES_KEY, JSON.stringify(services));
  }
};

export const deleteService = (id: string): void => {
  const services = getServices();
  const filtered = services.filter(service => service.id !== id);
  localStorage.setItem(SERVICES_KEY, JSON.stringify(filtered));
};

// Utility functions
const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const getAppointmentsByDate = (date: string): Appointment[] => {
  return getAppointments().filter(apt => apt.date === date);
};

export const getTodayAppointments = (): Appointment[] => {
  const today = new Date().toISOString().split('T')[0];
  return getAppointmentsByDate(today);
};

export const exportDayAppointments = (date: string): void => {
  const appointments = getAppointmentsByDate(date);
  const services = getServices();
  
  const csvContent = [
    'Cliente,Serviço,Horário,Telefone,Status,Preço',
    ...appointments.map(apt => {
      const service = services.find(s => s.id === apt.service);
      return `${apt.client},${service?.name || apt.service},${apt.time},${apt.phone},${getStatusText(apt.status)},R$ ${apt.price}`;
    })
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', `agendamentos_${date}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

const getStatusText = (status: string): string => {
  const statusMap: Record<string, string> = {
    pending: 'Pendente',
    confirmed: 'Confirmado',
    completed: 'Atendido',
    cancelled: 'Cancelado'
  };
  return statusMap[status] || status;
};