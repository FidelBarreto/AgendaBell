import React, { useState, useEffect } from 'react';
import { Calendar, Users, TrendingUp, Settings, Plus, Clock, Phone, Edit, Trash2, CheckCircle, X, Download, Check } from 'lucide-react';
import { getAppointments, getServices, updateAppointment, deleteAppointment, saveAppointment, type Appointment, type Service } from '../utils/storage';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [showNewAppointmentModal, setShowNewAppointmentModal] = useState(false);
  
  // New appointment form state
  const [newAppointment, setNewAppointment] = useState({
    client: '',
    service: '',
    time: '',
    phone: '',
    date: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setAppointments(getAppointments());
    setServices(getServices());
  };

  const confirmAppointment = (id: string) => {
    updateAppointment(id, { status: 'confirmed' });
    loadData();
  };

  const markAsCompleted = (id: string) => {
    updateAppointment(id, { status: 'completed' });
    loadData();
  };

  const cancelAppointment = (id: string) => {
    if (confirm('Tem certeza que deseja cancelar este agendamento?')) {
      deleteAppointment(id);
      loadData();
    }
  };

  const handleExportDay = () => {
    const selectedDateAppointments = appointments.filter(apt => apt.date === selectedDate);
    
    if (selectedDateAppointments.length === 0) {
      alert('Nenhum agendamento encontrado para esta data.');
      return;
    }

    const csvContent = [
      'Cliente,Serviço,Horário,Telefone,Status,Preço',
      ...selectedDateAppointments.map(apt => {
        const service = services.find(s => s.id === apt.service);
        return `${apt.client},${service?.name || apt.service},${apt.time},${apt.phone},${getStatusText(apt.status)},R$ ${apt.price}`;
      })
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `agendamentos_${selectedDate}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleNewAppointment = () => {
    setShowNewAppointmentModal(true);
  };

  const handleSaveNewAppointment = () => {
    if (!newAppointment.client || !newAppointment.service || !newAppointment.time || !newAppointment.phone) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    const selectedService = services.find(s => s.id === newAppointment.service);
    if (!selectedService) {
      alert('Serviço não encontrado.');
      return;
    }

    saveAppointment({
      client: newAppointment.client,
      service: newAppointment.service,
      time: newAppointment.time,
      date: newAppointment.date,
      phone: newAppointment.phone,
      status: 'confirmed',
      price: selectedService.price
    });

    setNewAppointment({
      client: '',
      service: '',
      time: '',
      phone: '',
      date: new Date().toISOString().split('T')[0]
    });
    setShowNewAppointmentModal(false);
    loadData();
  };

  const handleEditAppointment = (id: string) => {
    alert(`Editar agendamento ${id} - Funcionalidade em desenvolvimento!`);
  };

  const handleNewService = () => {
    alert('Funcionalidade de novo serviço em desenvolvimento!');
  };

  const handleEditService = (id: string) => {
    alert(`Editar serviço ${id} - Funcionalidade em desenvolvimento!`);
  };

  const handleDeleteService = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este serviço?')) {
      alert(`Excluir serviço ${id} - Funcionalidade em desenvolvimento!`);
    }
  };

  const getServiceName = (serviceId: string): string => {
    const service = services.find(s => s.id === serviceId);
    return service?.name || serviceId;
  };

  const getStatusColor = (status: string): string => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      confirmed: 'bg-blue-100 text-blue-800',
      completed: 'bg-green-100 text-green-800',
      cancelled: 'bg-red-100 text-red-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getStatusText = (status: string): string => {
    const statusMap = {
      pending: 'Pendente',
      confirmed: 'Confirmado',
      completed: 'Atendido',
      cancelled: 'Cancelado'
    };
    return statusMap[status as keyof typeof statusMap] || status;
  };

  const todayAppointments = appointments.filter(apt => apt.date === new Date().toISOString().split('T')[0]);
  const selectedDateAppointments = appointments.filter(apt => apt.date === selectedDate);
  const pendingConfirmations = appointments.filter(apt => apt.status === 'pending').length;
  const monthlyRevenue = appointments
    .filter(apt => apt.status === 'completed' && apt.date.startsWith(new Date().toISOString().slice(0, 7)))
    .reduce((sum, apt) => sum + apt.price, 0);
  const totalClients = new Set(appointments.map(apt => apt.client)).size;

  const availableTimes = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
  ];

  const TabButton = ({ id, label, icon, isActive, onClick }: any) => (
    <button
      onClick={() => onClick(id)}
      className={`flex items-center space-x-2 px-4 py-3 rounded-lg font-medium transition-all duration-300 ${
        isActive 
          ? 'bg-gradient-to-r from-beauty-500 to-rose-500 text-white shadow-lg' 
          : 'text-gray-600 hover:bg-gray-100'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-beauty-500 to-rose-500 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Studio Maria</h1>
                <p className="text-sm text-gray-500">Painel Administrativo</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={handleNewAppointment}
                className="bg-gradient-to-r from-beauty-500 to-rose-500 text-white px-4 py-2 rounded-lg hover:from-beauty-600 hover:to-rose-600 transition-all duration-300"
              >
                <Plus className="w-4 h-4 mr-2 inline" />
                Novo Agendamento
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64">
            <nav className="space-y-2">
              <TabButton
                id="dashboard"
                label="Dashboard"
                icon={<TrendingUp className="w-5 h-5" />}
                isActive={activeTab === 'dashboard'}
                onClick={setActiveTab}
              />
              <TabButton
                id="appointments"
                label="Agendamentos"
                icon={<Calendar className="w-5 h-5" />}
                isActive={activeTab === 'appointments'}
                onClick={setActiveTab}
              />
              <TabButton
                id="clients"
                label="Clientes"
                icon={<Users className="w-5 h-5" />}
                isActive={activeTab === 'clients'}
                onClick={setActiveTab}
              />
              <TabButton
                id="services"
                label="Serviços"
                icon={<Settings className="w-5 h-5" />}
                isActive={activeTab === 'services'}
                onClick={setActiveTab}
              />
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Dashboard Tab */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
                
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white p-6 rounded-xl shadow-sm border">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Agendamentos Hoje</p>
                        <p className="text-2xl font-bold text-gray-900">{todayAppointments.length}</p>
                      </div>
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Calendar className="w-6 h-6 text-blue-600" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white p-6 rounded-xl shadow-sm border">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Pendentes</p>
                        <p className="text-2xl font-bold text-gray-900">{pendingConfirmations}</p>
                      </div>
                      <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <Clock className="w-6 h-6 text-yellow-600" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white p-6 rounded-xl shadow-sm border">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Receita do Mês</p>
                        <p className="text-2xl font-bold text-gray-900">R$ {monthlyRevenue}</p>
                      </div>
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-green-600" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white p-6 rounded-xl shadow-sm border">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Total de Clientes</p>
                        <p className="text-2xl font-bold text-gray-900">{totalClients}</p>
                      </div>
                      <div className="w-12 h-12 bg-beauty-100 rounded-lg flex items-center justify-center">
                        <Users className="w-6 h-6 text-beauty-600" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Appointments */}
                <div className="bg-white rounded-xl shadow-sm border">
                  <div className="p-6 border-b">
                    <h3 className="text-lg font-semibold text-gray-900">Próximos Agendamentos</h3>
                  </div>
                  <div className="p-6">
                    <div className="space-y-4">
                      {todayAppointments.slice(0, 4).map((appointment) => (
                        <div key={appointment.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-gradient-to-r from-beauty-500 to-rose-500 rounded-full flex items-center justify-center text-white font-semibold">
                              {appointment.client.split(' ').map(n => n[0]).join('')}
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">{appointment.client}</p>
                              <p className="text-sm text-gray-600">{getServiceName(appointment.service)}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-gray-900">{appointment.time}</p>
                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(appointment.status)}`}>
                              {getStatusText(appointment.status)}
                            </span>
                          </div>
                        </div>
                      ))}
                      {todayAppointments.length === 0 && (
                        <p className="text-gray-500 text-center py-4">Nenhum agendamento para hoje</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Appointments Tab */}
            {activeTab === 'appointments' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">Agendamentos</h2>
                  <div className="flex items-center space-x-4">
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-beauty-500 focus:border-transparent"
                    />
                    <button
                      onClick={handleExportDay}
                      className="flex items-center bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-all duration-300"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Exportar Dia
                    </button>
                  </div>
                </div>
                
                <div className="bg-white rounded-xl shadow-sm border">
                  <div className="p-6 border-b">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {new Date(selectedDate).toLocaleDateString('pt-BR', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </h3>
                      <button 
                        onClick={handleNewAppointment}
                        className="bg-gradient-to-r from-beauty-500 to-rose-500 text-white px-4 py-2 rounded-lg hover:from-beauty-600 hover:to-rose-600 transition-all duration-300"
                      >
                        <Plus className="w-4 h-4 mr-2 inline" />
                        Adicionar
                      </button>
                    </div>
                  </div>
                  <div className="divide-y">
                    {selectedDateAppointments.length > 0 ? (
                      selectedDateAppointments
                        .sort((a, b) => a.time.localeCompare(b.time))
                        .map((appointment) => (
                        <div key={appointment.id} className="p-6 hover:bg-gray-50 transition-colors duration-200">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <div className="w-12 h-12 bg-gradient-to-r from-beauty-500 to-rose-500 rounded-full flex items-center justify-center text-white font-semibold">
                                {appointment.client.split(' ').map(n => n[0]).join('')}
                              </div>
                              <div>
                                <p className="font-semibold text-gray-900">{appointment.client}</p>
                                <p className="text-sm text-gray-600">{getServiceName(appointment.service)}</p>
                                <div className="flex items-center mt-1 text-sm text-gray-500">
                                  <Clock className="w-4 h-4 mr-1" />
                                  {appointment.time}
                                  <Phone className="w-4 h-4 ml-3 mr-1" />
                                  {appointment.phone}
                                  <span className="ml-3 font-semibold text-beauty-600">R$ {appointment.price}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(appointment.status)}`}>
                                {getStatusText(appointment.status)}
                              </span>
                              {appointment.status === 'pending' && (
                                <button
                                  onClick={() => confirmAppointment(appointment.id)}
                                  className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                                  title="Confirmar"
                                >
                                  <CheckCircle className="w-5 h-5" />
                                </button>
                              )}
                              {(appointment.status === 'confirmed' || appointment.status === 'pending') && (
                                <button
                                  onClick={() => markAsCompleted(appointment.id)}
                                  className="p-2 text-green-600 hover:bg-green-100 rounded-lg transition-colors duration-200"
                                  title="Marcar como atendido"
                                >
                                  <Check className="w-5 h-5" />
                                </button>
                              )}
                              <button 
                                onClick={() => handleEditAppointment(appointment.id)}
                                className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                                title="Editar"
                              >
                                <Edit className="w-5 h-5" />
                              </button>
                              <button
                                onClick={() => cancelAppointment(appointment.id)}
                                className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                                title="Cancelar"
                              >
                                <X className="w-5 h-5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-6 text-center text-gray-500">
                        Nenhum agendamento para esta data
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Services Tab */}
            {activeTab === 'services' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Serviços</h2>
                
                <div className="bg-white rounded-xl shadow-sm border">
                  <div className="p-6 border-b">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-semibold text-gray-900">Lista de Serviços</h3>
                      <button 
                        onClick={handleNewService}
                        className="bg-gradient-to-r from-beauty-500 to-rose-500 text-white px-4 py-2 rounded-lg hover:from-beauty-600 hover:to-rose-600 transition-all duration-300"
                      >
                        <Plus className="w-4 h-4 mr-2 inline" />
                        Novo Serviço
                      </button>
                    </div>
                  </div>
                  <div className="divide-y">
                    {services.map((service) => (
                      <div key={service.id} className="p-6 hover:bg-gray-50 transition-colors duration-200">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-semibold text-gray-900">{service.name}</h4>
                            <div className="flex items-center mt-1 text-sm text-gray-500">
                              <Clock className="w-4 h-4 mr-1" />
                              {service.duration} min
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            <span className="text-lg font-bold text-beauty-600">R$ {service.price}</span>
                            <div className="flex items-center space-x-2">
                              <button 
                                onClick={() => handleEditService(service.id)}
                                className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                                title="Editar serviço"
                              >
                                <Edit className="w-5 h-5" />
                              </button>
                              <button 
                                onClick={() => handleDeleteService(service.id)}
                                className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                                title="Excluir serviço"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Clients Tab */}
            {activeTab === 'clients' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Clientes</h2>
                
                <div className="bg-white rounded-xl shadow-sm border">
                  <div className="p-6 border-b">
                    <h3 className="text-lg font-semibold text-gray-900">Lista de Clientes</h3>
                  </div>
                  <div className="p-6">
                    <div className="space-y-4">
                      {Array.from(new Set(appointments.map(apt => apt.client))).map((clientName) => {
                        const clientAppointments = appointments.filter(apt => apt.client === clientName);
                        const lastAppointment = clientAppointments.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
                        const totalSpent = clientAppointments.filter(apt => apt.status === 'completed').reduce((sum, apt) => sum + apt.price, 0);
                        
                        return (
                          <div key={clientName} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                            <div className="flex items-center space-x-4">
                              <div className="w-10 h-10 bg-gradient-to-r from-beauty-500 to-rose-500 rounded-full flex items-center justify-center text-white font-semibold">
                                {clientName.split(' ').map(n => n[0]).join('')}
                              </div>
                              <div>
                                <p className="font-semibold text-gray-900">{clientName}</p>
                                <p className="text-sm text-gray-600">{lastAppointment?.phone}</p>
                                <p className="text-xs text-gray-500">
                                  Último agendamento: {lastAppointment ? new Date(lastAppointment.date).toLocaleDateString('pt-BR') : 'Nunca'}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-semibold text-beauty-600">R$ {totalSpent}</p>
                              <p className="text-sm text-gray-600">{clientAppointments.length} agendamentos</p>
                            </div>
                          </div>
                        );
                      })}
                      {appointments.length === 0 && (
                        <p className="text-gray-500 text-center py-4">Nenhum cliente cadastrado ainda</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* New Appointment Modal */}
      {showNewAppointmentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Novo Agendamento</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome do Cliente *
                </label>
                <input
                  type="text"
                  value={newAppointment.client}
                  onChange={(e) => setNewAppointment({...newAppointment, client: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-beauty-500 focus:border-transparent"
                  placeholder="Nome completo"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Telefone *
                </label>
                <input
                  type="tel"
                  value={newAppointment.phone}
                  onChange={(e) => setNewAppointment({...newAppointment, phone: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-beauty-500 focus:border-transparent"
                  placeholder="(11) 99999-9999"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Serviço *
                </label>
                <select
                  value={newAppointment.service}
                  onChange={(e) => setNewAppointment({...newAppointment, service: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-beauty-500 focus:border-transparent"
                >
                  <option value="">Selecione um serviço</option>
                  {services.map((service) => (
                    <option key={service.id} value={service.id}>
                      {service.name} - R$ {service.price}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Data *
                </label>
                <input
                  type="date"
                  value={newAppointment.date}
                  onChange={(e) => setNewAppointment({...newAppointment, date: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-beauty-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Horário *
                </label>
                <select
                  value={newAppointment.time}
                  onChange={(e) => setNewAppointment({...newAppointment, time: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-beauty-500 focus:border-transparent"
                >
                  <option value="">Selecione um horário</option>
                  {availableTimes.map((time) => (
                    <option key={time} value={time}>
                      {time}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end space-x-4 mt-8">
              <button
                onClick={() => setShowNewAppointmentModal(false)}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              >
                Cancelar
              </button>
              <button
                onClick={handleSaveNewAppointment}
                className="px-4 py-2 bg-gradient-to-r from-beauty-500 to-rose-500 text-white rounded-lg hover:from-beauty-600 hover:to-rose-600 transition-all duration-300"
              >
                Salvar Agendamento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;