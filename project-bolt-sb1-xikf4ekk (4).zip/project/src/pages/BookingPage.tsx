import React, { useState } from 'react';
import { Calendar, Clock, User, Phone, MessageCircle, CheckCircle, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { saveAppointment, getServices } from '../utils/storage';

const BookingPage = () => {
  const [selectedService, setSelectedService] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [step, setStep] = useState(1);

  const services = getServices();

  const availableTimes = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
  ];

  const handleBooking = () => {
    const selectedServiceData = services.find(s => s.id === selectedService);
    
    if (selectedServiceData) {
      saveAppointment({
        client: clientName,
        service: selectedService,
        time: selectedTime,
        date: selectedDate,
        phone: clientPhone,
        status: 'pending',
        price: selectedServiceData.price
      });
    }
    
    setStep(4);
  };

  const generateWhatsAppLink = () => {
    const selectedServiceData = services.find(s => s.id === selectedService);
    const message = `Olá! Gostaria de agendar um ${selectedServiceData?.name} para ${selectedDate} às ${selectedTime}. Meu nome é ${clientName} e meu telefone é ${clientPhone}.`;
    return `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-beauty-50 to-rose-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <Link to="/" className="flex items-center text-gray-600 hover:text-gray-900">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Voltar
            </Link>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900">Studio Maria</h1>
              <p className="text-gray-600">Salão de Beleza & Estética</p>
            </div>
            <div className="w-20"></div> {/* Spacer */}
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4">
            {[1, 2, 3, 4].map((stepNumber) => (
              <div key={stepNumber} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                  step >= stepNumber 
                    ? 'bg-gradient-to-r from-beauty-500 to-rose-500 text-white' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {step > stepNumber ? <CheckCircle className="w-5 h-5" /> : stepNumber}
                </div>
                {stepNumber < 4 && (
                  <div className={`w-16 h-1 mx-2 ${
                    step > stepNumber ? 'bg-gradient-to-r from-beauty-500 to-rose-500' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-center mt-2 space-x-8 text-sm text-gray-600">
            <span className={step >= 1 ? 'text-beauty-600' : ''}>Serviço</span>
            <span className={step >= 2 ? 'text-beauty-600' : ''}>Data & Hora</span>
            <span className={step >= 3 ? 'text-beauty-600' : ''}>Seus Dados</span>
            <span className={step >= 4 ? 'text-beauty-600' : ''}>Confirmação</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Step 1: Service Selection */}
          {step === 1 && (
            <div className="animate-fade-in">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Escolha seu serviço
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {services.map((service) => (
                  <div
                    key={service.id}
                    onClick={() => setSelectedService(service.id)}
                    className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-300 hover:shadow-lg ${
                      selectedService === service.id
                        ? 'border-beauty-500 bg-beauty-50'
                        : 'border-gray-200 hover:border-beauty-300'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">{service.name}</h3>
                      <span className="text-lg font-bold text-beauty-600">R$ {service.price}</span>
                    </div>
                    <div className="flex items-center text-gray-500 text-sm">
                      <Clock className="w-4 h-4 mr-1" />
                      {service.duration}min
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-8 text-center">
                <button
                  onClick={() => setStep(2)}
                  disabled={!selectedService}
                  className="bg-gradient-to-r from-beauty-500 to-rose-500 text-white px-8 py-3 rounded-full font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:from-beauty-600 hover:to-rose-600 transition-all duration-300"
                >
                  Continuar
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Date & Time Selection */}
          {step === 2 && (
            <div className="animate-fade-in">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Escolha data e horário
              </h2>
              
              {/* Date Selection */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Data</h3>
                <div className="grid grid-cols-7 gap-2">
                  {Array.from({ length: 14 }, (_, i) => {
                    const date = new Date();
                    date.setDate(date.getDate() + i);
                    const dateString = date.toISOString().split('T')[0];
                    const dayName = date.toLocaleDateString('pt-BR', { weekday: 'short' });
                    const dayNumber = date.getDate();
                    
                    return (
                      <div
                        key={i}
                        onClick={() => setSelectedDate(dateString)}
                        className={`p-3 text-center rounded-lg cursor-pointer transition-all duration-300 ${
                          selectedDate === dateString
                            ? 'bg-gradient-to-r from-beauty-500 to-rose-500 text-white'
                            : 'bg-gray-50 hover:bg-gray-100'
                        }`}
                      >
                        <div className="text-xs opacity-75">{dayName}</div>
                        <div className="font-semibold">{dayNumber}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Time Selection */}
              {selectedDate && (
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Horário</h3>
                  <div className="grid grid-cols-4 md:grid-cols-6 gap-3">
                    {availableTimes.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`p-3 rounded-lg font-semibold transition-all duration-300 ${
                          selectedTime === time
                            ? 'bg-gradient-to-r from-beauty-500 to-rose-500 text-white'
                            : 'bg-gray-50 hover:bg-gray-100 text-gray-700'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-center space-x-4">
                <button
                  onClick={() => setStep(1)}
                  className="border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-full font-semibold hover:bg-gray-50 transition-all duration-300"
                >
                  Voltar
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={!selectedDate || !selectedTime}
                  className="bg-gradient-to-r from-beauty-500 to-rose-500 text-white px-8 py-3 rounded-full font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:from-beauty-600 hover:to-rose-600 transition-all duration-300"
                >
                  Continuar
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Client Info */}
          {step === 3 && (
            <div className="animate-fade-in">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Seus dados para contato
              </h2>
              <div className="max-w-md mx-auto space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome completo
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="text"
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-beauty-500 focus:border-transparent"
                      placeholder="Seu nome"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    WhatsApp
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="tel"
                      value={clientPhone}
                      onChange={(e) => setClientPhone(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-beauty-500 focus:border-transparent"
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-center space-x-4 mt-8">
                <button
                  onClick={() => setStep(2)}
                  className="border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-full font-semibold hover:bg-gray-50 transition-all duration-300"
                >
                  Voltar
                </button>
                <button
                  onClick={handleBooking}
                  disabled={!clientName || !clientPhone}
                  className="bg-gradient-to-r from-beauty-500 to-rose-500 text-white px-8 py-3 rounded-full font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:from-beauty-600 hover:to-rose-600 transition-all duration-300"
                >
                  Finalizar Agendamento
                </button>
              </div>
            </div>
          )}

          {/* Step 4: Confirmation */}
          {step === 4 && (
            <div className="animate-fade-in text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Agendamento Realizado!
              </h2>
              <div className="bg-gray-50 rounded-xl p-6 max-w-md mx-auto mb-8">
                <div className="space-y-3 text-left">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Serviço:</span>
                    <span className="font-semibold">
                      {services.find(s => s.id === selectedService)?.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Data:</span>
                    <span className="font-semibold">
                      {new Date(selectedDate).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Horário:</span>
                    <span className="font-semibold">{selectedTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Cliente:</span>
                    <span className="font-semibold">{clientName}</span>
                  </div>
                  <div className="flex justify-between border-t pt-3">
                    <span className="text-gray-600">Total:</span>
                    <span className="font-bold text-beauty-600">
                      R$ {services.find(s => s.id === selectedService)?.price}
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 mb-6">
                Confirme seu agendamento pelo WhatsApp clicando no botão abaixo:
              </p>
              <a
                href={generateWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center bg-green-500 text-white px-8 py-3 rounded-full font-semibold hover:bg-green-600 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Confirmar no WhatsApp
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookingPage;