import React from 'react';
import { Calendar, Smartphone, Users, TrendingUp, CheckCircle, Star, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const LandingPage = () => {
  const handleStartFree = () => {
    // Redirecionar para página de cadastro ou mostrar modal
    alert('Funcionalidade de cadastro em desenvolvimento!');
  };

  const handleStartNow = () => {
    // Redirecionar para página de planos ou checkout
    alert('Funcionalidade de planos em desenvolvimento!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-beauty-50 to-rose-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-beauty-500 to-rose-500 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">AgendaBell</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#features" className="text-gray-600 hover:text-beauty-600 transition-colors">Funcionalidades</a>
              <a href="#pricing" className="text-gray-600 hover:text-beauty-600 transition-colors">Preços</a>
              <a href="#demo" className="text-gray-600 hover:text-beauty-600 transition-colors">Demo</a>
            </nav>
            <div className="flex items-center space-x-4">
              <Link to="/admin" className="text-gray-600 hover:text-beauty-600 transition-colors">Login</Link>
              <button 
                onClick={handleStartFree}
                className="bg-gradient-to-r from-beauty-500 to-rose-500 text-white px-6 py-2 rounded-full hover:from-beauty-600 hover:to-rose-600 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Começar Grátis
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div className="animate-fade-in">
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Agenda Inteligente para
                <span className="bg-gradient-to-r from-beauty-500 to-rose-500 bg-clip-text text-transparent"> Salões de Beleza</span>
              </h1>
              <p className="mt-6 text-xl text-gray-600 leading-relaxed">
                Simplifique o agendamento do seu salão com nossa plataforma intuitiva. 
                Seus clientes agendam pelo WhatsApp, você gerencia tudo em um só lugar.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={handleStartFree}
                  className="bg-gradient-to-r from-beauty-500 to-rose-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:from-beauty-600 hover:to-rose-600 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center"
                >
                  Experimentar Grátis
                  <ArrowRight className="ml-2 w-5 h-5" />
                </button>
                <Link to="/salon/studio-maria" className="border-2 border-beauty-500 text-beauty-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-beauty-50 transition-all duration-300 flex items-center justify-center">
                  Ver Demo
                </Link>
              </div>
            </div>
            <div className="mt-12 lg:mt-0 relative animate-slide-up">
              <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md mx-auto">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-r from-beauty-500 to-rose-500 rounded-full flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Studio Maria</h3>
                    <p className="text-gray-500 text-sm">Salão de Beleza</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-beauty-50 rounded-lg">
                    <span className="text-gray-700">Corte + Escova</span>
                    <span className="text-beauty-600 font-semibold">R$ 80</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-rose-50 rounded-lg">
                    <span className="text-gray-700">Manicure</span>
                    <span className="text-rose-600 font-semibold">R$ 35</span>
                  </div>
                  <button className="w-full bg-gradient-to-r from-beauty-500 to-rose-500 text-white py-3 rounded-lg font-semibold hover:from-beauty-600 hover:to-rose-600 transition-all duration-300">
                    Agendar Horário
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Tudo que você precisa em uma só plataforma
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Desenvolvido especialmente para profissionais da beleza que querem modernizar seu negócio
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Smartphone className="w-8 h-8" />,
                title: "Agendamento via WhatsApp",
                description: "Seus clientes agendam direto pelo WhatsApp com link personalizado"
              },
              {
                icon: <Calendar className="w-8 h-8" />,
                title: "Agenda Inteligente",
                description: "Gerencie horários, serviços e profissionais em uma interface simples"
              },
              {
                icon: <Users className="w-8 h-8" />,
                title: "Gestão de Clientes",
                description: "Histórico completo, preferências e anotações personalizadas"
              },
              {
                icon: <TrendingUp className="w-8 h-8" />,
                title: "Relatórios Simples",
                description: "Acompanhe o desempenho do seu salão com dados claros e objetivos"
              },
              {
                icon: <CheckCircle className="w-8 h-8" />,
                title: "Lembretes Automáticos",
                description: "Reduza faltas com confirmações e lembretes por WhatsApp"
              },
              {
                icon: <Star className="w-8 h-8" />,
                title: "Página Personalizada",
                description: "Link exclusivo com a marca do seu salão para compartilhar"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-2xl hover:bg-white hover:shadow-lg transition-all duration-300 group">
                <div className="text-beauty-500 mb-4 group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section id="demo" className="py-20 bg-gradient-to-r from-beauty-500 to-rose-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
            Veja o AgendaBell em ação
          </h2>
          <p className="text-xl text-beauty-100 mb-8 max-w-2xl mx-auto">
            Experimente nossa demo e veja como é fácil gerenciar seu salão
          </p>
          <Link to="/salon/studio-maria" className="inline-flex items-center bg-white text-beauty-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-beauty-50 transition-all duration-300 shadow-lg hover:shadow-xl">
            Acessar Demo
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Planos que cabem no seu bolso
            </h2>
            <p className="text-xl text-gray-600">
              Comece grátis e evolua conforme seu salão cresce
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: "Starter",
                price: "Gratuito",
                features: ["Até 50 agendamentos/mês", "1 profissional", "WhatsApp básico", "Suporte por email"]
              },
              {
                name: "Professional",
                price: "R$ 29/mês",
                popular: true,
                features: ["Agendamentos ilimitados", "Até 3 profissionais", "WhatsApp automático", "Relatórios completos", "Suporte prioritário"]
              },
              {
                name: "Studio",
                price: "R$ 59/mês",
                features: ["Profissionais ilimitados", "Multi-unidades", "API personalizada", "Integrações avançadas", "Suporte dedicado"]
              }
            ].map((plan, index) => (
              <div key={index} className={`relative p-8 rounded-2xl ${plan.popular ? 'bg-gradient-to-br from-beauty-500 to-rose-500 text-white scale-105' : 'bg-gray-50 hover:bg-white hover:shadow-lg'} transition-all duration-300`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-yellow-400 text-yellow-900 px-4 py-1 rounded-full text-sm font-semibold">
                      Mais Popular
                    </span>
                  </div>
                )}
                <h3 className={`text-2xl font-bold mb-2 ${plan.popular ? 'text-white' : 'text-gray-900'}`}>
                  {plan.name}
                </h3>
                <div className="mb-6">
                  <span className={`text-4xl font-bold ${plan.popular ? 'text-white' : 'text-gray-900'}`}>
                    {plan.price}
                  </span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <CheckCircle className={`w-5 h-5 mr-3 ${plan.popular ? 'text-beauty-200' : 'text-beauty-500'}`} />
                      <span className={plan.popular ? 'text-beauty-100' : 'text-gray-600'}>
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={handleStartNow}
                  className={`w-full py-3 rounded-lg font-semibold transition-all duration-300 ${
                    plan.popular 
                      ? 'bg-white text-beauty-600 hover:bg-beauty-50' 
                      : 'bg-gradient-to-r from-beauty-500 to-rose-500 text-white hover:from-beauty-600 hover:to-rose-600'
                  }`}
                >
                  Começar Agora
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center space-x-2 mb-8">
            <div className="w-8 h-8 bg-gradient-to-r from-beauty-500 to-rose-500 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">AgendaBell</span>
          </div>
          <div className="text-center text-gray-400">
            <p>&copy; 2025 AgendaBell. Todos os direitos reservados.</p>
            <p className="mt-2">Simplifique sua agenda, encante seus clientes.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;